import pickle
from Backend import search

ingredients_ids = pickle.load(open("Backend/data/ingredient_ids.pickle", "rb"))
try:
    new_dict = eval(open("Backend/data/ingredient_aliases.json", "r").read())
except FileNotFoundError:
    new_dict = {}

start = int(input("Enter index you want to start at: "))
for i, ingredient in enumerate(ingredients_ids[start:]):
    desired_name = input(" {} -> ".format(ingredient[1].strip()))
    if desired_name == "":
        desired_name = ingredient[1].strip()

    # -q to stop
    if desired_name == "-q":
        print("To continue, start at index {} next time.".format(start + i))
        break
    # -r to remove a bad string
    if desired_name == "-r":
        print("   {} removed".format(ingredient[1]))
        continue
    # -s to search for similar ingredients
    if desired_name == "-s":
        print("   By string:")
        for s in search.similar_strings(ingredient[1]):
            print("    {0:.2f} - {1}".format(s[1], s[0]))
        try:
            print("   By vector:")
            for s in search.similar_vectors(ingredient[1].strip()):
                print("    {0:.2f} - {1}".format(s[1], s[0]))
        except KeyError:
            pass
        desired_name = input(" {} -> ".format(ingredient[1].strip()))
        if desired_name == "":
            desired_name = ingredient[1].strip()

    if desired_name in new_dict.keys():
        new_dict[desired_name]["aliases"].append(ingredient[1])
    else:
        new_dict[desired_name] = {"name": desired_name, "id": i, "aliases": [ingredient[1]]}

open("Backend/data/ingredient_aliases.json", "w").write(str(new_dict))
