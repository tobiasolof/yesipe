import bs4
import requests
import re
import json
import pickle
from multiprocessing import Pool


def get_links(prefix="http://www.tasteline.com/recept/", page_number=1):
    url = prefix + "?sida={}".format(page_number)
    html_doc = requests.get(url).text
    parse_tree = bs4.BeautifulSoup(html_doc, "html.parser")
    recipe_descriptions = parse_tree.find_all("div", "recipe-description")
    link_list = []
    for element in recipe_descriptions:
        link = str(element.a)
        link_list.append(re.search("http:" + ".+/\"", link).group()[:-1])
    return link_list


def get_ingredients(parse_tree):
    # TODO: If partitioned, do we get all ingredients?
    # http://www.tasteline.com/recept/asiatiska-bonbiffar-med-glasnudelsallad/
    ingredient_group = parse_tree.find_all("div", "ingredient-group")
    ingredient_list = [re.findall("ingredients\">.+<", str(element)) for element in ingredient_group][0]
    ingredient_list = [re.search(">.+?<", i).group().lower()[1:-1] for i in ingredient_list]
    ingredient_list = [i.strip() for i in ingredient_list]
    return ingredient_list


def get_instructions(parse_tree):
    step_group = parse_tree.find_all("div", "step-group")
    step_list = []
    for s in step_group:
        temp_step_list = []
        for element in s:
            p = re.compile('<li>[0-9]+\..+<|<h3>.+<')
            temp_step_list.extend(re.findall(p, str(element)))
        temp_step_list = [s[4:-1] for s in temp_step_list]
        step_list.extend(temp_step_list)
    step_list = "\n\n".join(step_list)
    return step_list


def get_image(parse_tree):
    header = parse_tree.find_all("div", "recipe-header-image")
    image = re.search("http:" + ".+\"?", str(header)).group()[:-2]
    return image


def get_title(parse_tree):
    recipe_description = parse_tree.find_all("div", "recipe-description")
    title = re.search("<h1 itemprop=\"name\">.+</h1>", str(recipe_description)).group()[20:-5]
    return title


def get_recipes(p):
    batch = []
    for i in range(1, 51):
        links = get_links(prefix=p, page_number=i)
        for l in links:
            try:
                html_doc = requests.get(l).text
                parse_tree = bs4.BeautifulSoup(html_doc, "html.parser")

                title = get_title(parse_tree)
                image = get_image(parse_tree)
                instructions = get_instructions(parse_tree)
                ingredients = get_ingredients(parse_tree)

                entry = {"id": l, "ingredients": ingredients, "title": title, "image": image,
                         "instructions": instructions}
                batch.append(entry)
                print(l)
            except:
                print("EXCEPTION. Skipped {}".format(l))
    print("Finished scraping {}".format(p))
    return batch

# ===============================

if __name__ == "__main__":
    p = Pool(100)
    prefix_list = open("Backend/data/tasteline_url").read().split("\n")
    category_map = p.map(get_recipes, prefix_list)
    print("\nFinished threaded scraping.\n")

    master_index = []
    for batch in category_map:
        for recipe in batch:
            if recipe not in master_index:
                master_index.append(recipe)

    with open('Backend/data/tasteline.json', 'w') as f:
        json.dump(master_index, f)
        print("Wrote {} recipes to {}".format(len(master_index), "tasteline.json"))

    with open('Backend/data/tasteline.pickle', 'wb') as f:
        pickle.dump(master_index, f)
        print("Wrote {} recipes to {}".format(len(master_index), "tasteline.pickle"))
