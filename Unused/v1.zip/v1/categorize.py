from multiprocessing import Pool, Value
import pickle
import urllib.request
import urllib.parse

ingredient_ids = pickle.load(open('Backend/data/ingredient_ids.pickle', 'rb'))
print('Number of ingredients to categorize: %d' % len(ingredient_ids))
frags_completed = Value('i', 0)

categories = [
    'Beverages (non-milk)',
    'Bread and Flour Products',
    'Condiments / Dressings',
    'Egg and egg products',
    'Fish and fish products',
    'Fruits / Nuts / Vegetables',
    'Meat and meat products',
    'Milk and milk products',
    'Plain Pasta / Plain Rice / Other Grains (not prepared)',
    # 'Prepared Meals',
    'Sauces / Gravies',
    'Soups',
    'Spices / Seasonings / Cooking Products',
    'Stock'
]


def find_categories(i):
    ingredient_string = i[1].replace('%', '').replace('/', '')
    global categories
    temp_list = []

    for j in range(10):
        try:
            with urllib.request.urlopen('http://'+urllib.parse.quote('www.foodfacts.com/ci/nutritionsearch/'+ingredient_string)) as response:
                page = response.read().decode()

            temp_categories = [(c, 0) for c in categories]
            for category in temp_categories:
                category = (category[0], page.count(category[0]))
                if category[1] > 1:
                    temp_list.append((category[0], category[1]))
                    # if len(temp_list) == 0:
                    # print('No hits')

            print([i[0], i[1], temp_list])
            with frags_completed.get_lock():
                frags_completed.value += 1
                if frags_completed.value % 100 == 0:
                    print('========================================')
                    print("completed %d fragments" % frags_completed.value)
                    print('========================================')
            return [i[0], i[1], temp_list]

        except:
            continue

    print('BAD REQUEST:\n'+'http://'+urllib.parse.quote('www.foodfacts.com/ci/nutritionsearch/'+ingredient_string))
    return [i[0], i[1], temp_list]


ingredients_with_categories = []
p = Pool(10)
category_map = p.map(find_categories, ingredient_ids)
print('Finished threaded lookup.')
for i, ingredient in enumerate(category_map):
    ingredients_with_categories.append(ingredient)

print("===================================")

for i in ingredients_with_categories[-20:]:
    print(i)
    
with open('Backend/data/ingredients_with_categories.pickle', 'wb') as f:
    pickle.dump(ingredients_with_categories, f)
